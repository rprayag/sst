package com.prayag.studentmgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentmgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
