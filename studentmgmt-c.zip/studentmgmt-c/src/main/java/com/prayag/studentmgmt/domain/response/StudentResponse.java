package com.prayag.studentmgmt.domain.response;

import com.prayag.studentmgmt.domain.entity.Student;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentResponse<T> {

    T data;
    String message;

}
