package com.prayag.studentmgmt.service;


import com.prayag.studentmgmt.domain.entity.Student;
import com.prayag.studentmgmt.domain.response.StudentResponse;
import com.prayag.studentmgmt.exception.StudentException;

import java.util.List;

public interface StudentService {

    StudentResponse createStudent(Student student) throws StudentException;

    StudentResponse<List<Student>> getStudents();

    StudentResponse<Student> getStudentbyId(String emailId);

    List<Student> getStudentbyStandard(int standard);

    StudentResponse<Student> updateStudent(Student student, String email);

    String deleteById(String email);

}
