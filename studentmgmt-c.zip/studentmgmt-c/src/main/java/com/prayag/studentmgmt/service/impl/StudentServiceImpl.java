package com.prayag.studentmgmt.service.impl;

import com.prayag.studentmgmt.domain.entity.Student;
import com.prayag.studentmgmt.domain.response.StudentResponse;
import com.prayag.studentmgmt.exception.StudentException;
import com.prayag.studentmgmt.repo.StudentRepository;
import com.prayag.studentmgmt.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Override
    public StudentResponse createStudent(Student student) throws StudentException {

        StudentResponse<Student> response = new StudentResponse<>();

        if (!validateIfAlreadyExists(student.getEmail())) {
            response.setData(studentRepository.save(student));
            response.setMessage("Successfully created student");
        } else {
            throw new StudentException("Student already exists");
        }

        return response;
    }

    @Override
    public StudentResponse<List<Student>> getStudents() {
        StudentResponse<List<Student>> studentResponse = new StudentResponse<>();
        List<Student> students = studentRepository.findAll();
        if (!students.isEmpty()) {
            studentResponse.setData(students);
            studentResponse.setMessage("Successfull");
        } else {
            studentResponse.setMessage("No data ");
        }
        return studentResponse;
    }

    @Override
    public StudentResponse<Student> getStudentbyId(String emailId) {

        StudentResponse<Student> studentResponse = new StudentResponse<>();
        Optional<Student> optionalStudent = studentRepository.findById(emailId.trim());
        if (optionalStudent.isPresent()) {
            studentResponse.setData(optionalStudent.get());
            studentResponse.setMessage("Succesfull");
        } else {
            studentResponse.setMessage("No student found with following email id: " + emailId);
        }

        return studentResponse;
    }

    @Override
    public List<Student> getStudentbyStandard(int standard) {
        return null;
    }

    @Override
    public StudentResponse<Student> updateStudent(Student student, String email) {

        StudentResponse<Student> studentResponse = new StudentResponse<>();

        Optional<Student> optionalStudent = studentRepository.findById(email.trim());
        if (optionalStudent.isPresent()) {
            Student existing = optionalStudent.get();
            existing.setFirstName(student.getFirstName());
            existing.setLastName(student.getLastName());
            existing.setStandard(student.getStandard());
            studentRepository.save(existing);
            studentResponse.setData(existing);
            studentResponse.setMessage("updated!!");
        } else {
            studentResponse.setMessage("Student does not exist for updating");
        }

        return studentResponse;

    }

    public String deleteById(String email) {
        Optional<Student> optionalStudent = studentRepository.findById(email.trim());
        if (optionalStudent.isPresent()) {
            studentRepository.deleteById(email);
            return "Deleted!!!";
        } else {
            return "Student do not exists";
        }

    }


    boolean validateIfAlreadyExists(String email) {
        return studentRepository.findById(email).isPresent();
    }
}
