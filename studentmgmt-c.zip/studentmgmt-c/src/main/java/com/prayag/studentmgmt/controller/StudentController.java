package com.prayag.studentmgmt.controller;

import com.prayag.studentmgmt.domain.entity.Student;
import com.prayag.studentmgmt.domain.response.StudentResponse;
import com.prayag.studentmgmt.exception.StudentException;
import com.prayag.studentmgmt.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/student")
@RequiredArgsConstructor
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping("/create")
    public ResponseEntity<StudentResponse<Student>> createStudent(@RequestBody Student student) {

        ResponseEntity<StudentResponse<Student>> responseEntity = null;
        StudentResponse studentResponse = null;
        try {
            studentResponse = studentService.createStudent(student);
            responseEntity = new ResponseEntity<>(studentResponse, HttpStatus.OK);
        } catch (StudentException e) {
            studentResponse = new StudentResponse(student, e.getMessage());
            responseEntity = new ResponseEntity<>(studentResponse, HttpStatus.CONFLICT);
        }
        return responseEntity;
    }

    @GetMapping("/getAll")
    public ResponseEntity<StudentResponse<List<Student>>> getAllStudents() {
        return new ResponseEntity<StudentResponse<List<Student>>>(studentService.getStudents(), HttpStatus.OK);
    }

    @GetMapping("/{email}")
    public ResponseEntity<StudentResponse<Student>> getbyEmailId(@PathVariable("email") String email) {
        return
                new ResponseEntity<StudentResponse<Student>>
                        (studentService.getStudentbyId(email), HttpStatus.OK);
    }

    @PutMapping("/{email}")
    public ResponseEntity<StudentResponse<Student>> updateStudent(@RequestBody Student student, @PathVariable String email) {

        return new ResponseEntity<StudentResponse<Student>>
                (studentService.updateStudent(student, email), HttpStatus.OK);

    }

    @DeleteMapping("/{email}")
    public ResponseEntity<String> deleteById(@PathVariable("email") String email) {
        return
                new ResponseEntity<String>
                        (studentService.deleteById(email), HttpStatus.OK);
    }


}

