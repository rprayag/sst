package com.prayag.studentmgmt.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Student {

    @Id
    @Column
    String email;

    @Column
    String firstName;

    @Column
    String lastName;

    @Column
    int standard;


}
