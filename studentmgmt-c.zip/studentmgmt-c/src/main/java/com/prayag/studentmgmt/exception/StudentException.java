package com.prayag.studentmgmt.exception;

import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@NoArgsConstructor

public class StudentException extends Exception {

    String message;

    public StudentException(String message) {
        super(message);
        this.message = message;
    }
}
